package eus.fpsanturtzilh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackPeluApplicationTests {

	@Test
	void contextLoads() {
	}

}
