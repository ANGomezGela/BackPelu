package eus.fpsanturtzilh.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import eus.fpsanturtzilh.entity.Produktu_mugimenduak;
import eus.fpsanturtzilh.repository.Produktu_mugimenduak_repository;

@Service
public class Produktu_mugimenduak_service {
    @Autowired
    Produktu_mugimenduak_repository produktu_mugimenduak_repository;

    // Obtener todos los movimientos de productos
    public ArrayList<Produktu_mugimenduak> getProduktu_mugimenduak() {
        return (ArrayList<Produktu_mugimenduak>) produktu_mugimenduak_repository.findAll();
    }

    // Guardar un nuevo movimiento de producto
    public Produktu_mugimenduak saveProduktu_mugimenduak(Produktu_mugimenduak produ) {
        return produktu_mugimenduak_repository.save(produ);
    }

    // Obtener un producto por ID
    public Optional<Produktu_mugimenduak> getById(Long id) {
        return produktu_mugimenduak_repository.findById(id);
    }

    // Actualizar un producto por ID
    public Produktu_mugimenduak updateById(Produktu_mugimenduak request, Long id) {
        Produktu_mugimenduak produ = produktu_mugimenduak_repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Producto no encontrado con ID: " + id));

        produ.setProduktua(request.getProduktua());
        produ.setLangilea(request.getLangilea());
        produ.setData(request.getData());
        produ.setKopurua(request.getKopurua());
        produ.setSortzeData(request.getSortzeData());
        produ.setEguneratzeData(LocalDateTime.now());  
        produ.setEzabatzeData(request.getEzabatzeData());

        return produktu_mugimenduak_repository.save(produ);
    }

    // Borrar un producto por ID
    public Boolean deleteproduktu_Mugimenduak(Long id) {
        try {
            produktu_mugimenduak_repository.deleteById(id);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // 📌 Método para devolver un producto
    public Boolean devolverProduktu(Long id) {
        Optional<Produktu_mugimenduak> optionalProduktu = produktu_mugimenduak_repository.findById(id);

        if (optionalProduktu.isPresent()) {
            Produktu_mugimenduak produ = optionalProduktu.get();
            
            // Actualizar la fecha de devolución
            produ.setEzabatzeData(LocalDateTime.now());
            
            // Guardar cambios en la base de datos
            produktu_mugimenduak_repository.save(produ);
            
            return true;
        } else {
            return false; // No se encontró el producto
        }
    }
}
