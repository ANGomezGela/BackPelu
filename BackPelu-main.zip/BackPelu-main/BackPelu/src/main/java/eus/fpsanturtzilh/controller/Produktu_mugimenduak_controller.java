package eus.fpsanturtzilh.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import eus.fpsanturtzilh.entity.Produktu_mugimenduak;
import eus.fpsanturtzilh.service.Produktu_mugimenduak_service;

@RestController
@RequestMapping("/produktu_mugimenduak")
@CrossOrigin(origins = "http://localhost:8100")
public class Produktu_mugimenduak_controller {
    
    @Autowired
    private Produktu_mugimenduak_service produktuak_Mugimendua_service;

    @GetMapping
    public List<Produktu_mugimenduak> getProduk() {
        return produktuak_Mugimendua_service.getProduktu_mugimenduak();
    }

    @PostMapping
    public Produktu_mugimenduak saveProduktu(@RequestBody Produktu_mugimenduak produ) {
        return produktuak_Mugimendua_service.saveProduktu_mugimenduak(produ);
    }

    @GetMapping("/{id}")
    public Optional<Produktu_mugimenduak> getProduktuById(@PathVariable Long id) {
        return produktuak_Mugimendua_service.getById(id);
    }

    @PutMapping("/{id}")
    public Produktu_mugimenduak updateProduktuById(@PathVariable Long id, @RequestBody Produktu_mugimenduak request) {
        return produktuak_Mugimendua_service.updateById(request, id);
    }

    @DeleteMapping("/{id}")
    public String deleteProduktuById(@PathVariable Long id) {
        boolean deleted = produktuak_Mugimendua_service.deleteproduktu_Mugimenduak(id);
        return deleted ? "Producto con ID " + id + " eliminado" : "Error al eliminar";
    }

    // 📌 Endpoint para registrar la devolución de un producto
    @PutMapping("/devolver/{id}")
    public String devolverProducto(@PathVariable Long id) {
        boolean returned = produktuak_Mugimendua_service.devolverProduktu(id);
        return returned ? "Producto con ID " + id + " devuelto" : "Error al devolver el producto";
    }
}
