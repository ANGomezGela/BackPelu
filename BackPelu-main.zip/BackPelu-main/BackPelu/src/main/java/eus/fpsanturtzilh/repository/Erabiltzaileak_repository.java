package eus.fpsanturtzilh.repository;

import eus.fpsanturtzilh.entity.Erabiltzaileak;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Erabiltzaileak_repository extends JpaRepository<Erabiltzaileak, String> {
}
